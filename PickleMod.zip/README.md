# :cucumber: Pickle Mod
Discord bot for server moderation purposes.

This source is made available explicitly for purposes of transparency with regards
to the use of the relatively drastic permissions a moderation bot requires to function.
I will not help you adapt my code to your own purposes.

For support you can go to the official support Discord server: https://discord.gg/CW48Pkp  
A permanent bot invite link can be found there along with a permanent post containing
the setup guide

>**Disclaimer:** The support server is explicitly for support for the usage of
the instance my bot, `Pickle Mod#2744 (ID 264411398736445441)`, that I host, run,
and maintain on my server. I do **NOT** provide support for attempting to run your
own instance of my bot, modified or otherwise. I do not and will not provide code
support on the support server. In addition, you will not receive any help regarding
bans in any server. I am not associated directly with the majority of servers the
bot serves and I cannot (nor do I have the authority to) do anything for you in
this regard.
