import { Collection, RichEmbed } from 'discord.js';
import { Client, Command, GuildStorage, Message } from 'yamdbf';

export default class extends Command<Client>
{
	public constructor()
	{
		super({
			name: 'help',
			desc: 'Provides information on bot commands',
			usage: `<prefix>help [command]`,
			info: 'Will DM bot command help information to the user to keep clutter down in guild channels. If you use the help command from within a DM you will only receive information for the commands you can use within the DM. If you want help with commands usable in a guild, call the help command in a guild channel. You will receive a list of the commands that you have permissions/roles for in that channel.'
		});
	}

	public async action(message: Message, [commandName]: [string]): Promise<any>
	{
		const dm: boolean = message.channel.type === 'dm' || message.channel.type === 'group';
		const mentionName: string = `@${this.client.user.tag}`;
		const prefix: string = !dm ? await message.guild.storage.settings.get('prefix') : '';

		let usableCommands: Collection<string, Command<any>> =
			new Collection<string, Command<any>>(this.client.commands.entries());
		let command: Command<any>;
		let output: string = '';
		let embed: RichEmbed = new RichEmbed();

		if (!commandName)
		{
			embed.setAuthor('Moderatie commands', this.client.user.avatarURL)
				.addField(`${prefix}warn <Lid> <...Reden>`, 'Geef een waarschuwing')
				.addField(`${prefix}mute <Lid> <Duratie> <...Reden>`,
					`Mute een lid\n`
					+ 'Duratie voorbeelden: `30m`, `2h`, `1d`', true)
				.addField(`${prefix}unmute <Speler>`, `Unmute een speler`, true)
				.addField(`${prefix}kick <Speler> <...Reden>`, `Kick een speler`)
				.addField(`${prefix}softban <Speler> <...Reden>`, `Kick een speler, en verwijder de berichten die door de speler gestuurd zijn`)
				.addField(`${prefix}ban <Speler> <...Reden>`, `Ban een speler`, true)
				.addField(`${prefix}unban <Speler> <...Reden>`, `Unban een speler`, true)
				.addField(`${prefix}Reden <#|#-#|latest> <...Reden>`, `Zet een reden voor een straf`)
				.addField(`${prefix}lockdown <Duratie> [#channel]`,
					`Lockdown een channel\n`
					+ 'Duratie voorbeeldrn `30m`, `2h`, `1d`');

			for (const cmd of ['warn', 'mute', 'unmute', 'kick', 'softban', 'ban', 'unban', 'reason', 'lockdown',
				'eval', 'eval:ts', '$', 'setlang', 'reload', 'usagestats'])
				usableCommands.delete(cmd);

			if (message.guild)
			{
				const storage: GuildStorage = message.guild.storage;
				for (const [name, cmd] of usableCommands.entries())
					if (await storage.settings.exists('disabledGroups')
						&& (await storage.settings.get('disabledGroups') || []).includes(cmd.group))
						usableCommands.delete(name);
			}

			embed.addField('Other commands', usableCommands.map((c: Command<any>) => c.name).join(', '))
				.addField('\u200b', `Gebruik \`help <Commando>\` ${this.client.selfbot ? '' : `or \`${
					mentionName} help <Commando>\` `}for more information.\n\n`);
		}
		else
		{
			command = this.client.commands
				.filter(c => !(!this.client.isOwner(message.author) && c.ownerOnly))
				.find(c => c.name === commandName || c.aliases.includes(commandName));

			if (!command) output = `A command by that name could not be found or you do\n`
				+ `not have permission to view it.`;
			else output = '```ldif\n'
				+ (command.guildOnly ? '[Server Only]\n' : '')
				+ (command.ownerOnly ? '[Owner Only]\n' : '')
				+ `Commando: ${command.name}\n`
				+ `Beschrijving: ${command.desc}\n`
				+ (command.aliases.length > 0 ? `Aliases: ${command.aliases.join(', ')}\n` : '')
				+ `Gebruik: ${command.usage}\n`
				+ (command.info ? `\n${command.info}` : '')
				+ '\n```';
		}

		output = dm ? output.replace(/<prefix>/g, '')
			: output.replace(/<prefix>/g, await this.client.getPrefix(message.guild) || '');

		embed.setColor(11854048).setDescription(output);

		try
		{
			await message.author.send({ embed });
			if (!dm && command) message.reply(`Check je priveberichten`);
			if (!dm && !command) message.reply(`Check je priveberichten`);

		}
		catch
		{
			message.reply('Ik kan geen privebericht naar jou toesturen, heb je het uitstaan?');
		}
	}

	private _padRight(text: string, width: int): string
	{
		let pad: int = Math.max(0, Math.min(width, width - text.length));
		return `${text}${' '.repeat(pad)}`;
	}
}
