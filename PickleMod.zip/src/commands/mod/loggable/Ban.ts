import { Command, Message, Middleware, CommandDecorators, Logger, logger, Lang, ResourceLoader } from 'yamdbf';
import { User, GuildMember, RichEmbed, Collection } from 'discord.js';
import { prompt, PromptResult } from '../../../util/Util';
import { modOnly } from '../../../util/Util';
import { ModClient } from '../../../client/ModClient';

const { resolve, expect } = Middleware;
const { using } = CommandDecorators;
const res: ResourceLoader = Lang.createResourceLoader('en_us');

export default class extends Command<ModClient>
{
	@logger('Command:Ban')
	private readonly _logger: Logger;

	public constructor()
	{
		super({
			name: 'ban',
			aliases: ['b&', 'banne'],
			desc: 'Ban a user',
			usage: '<prefix>ban <Gebruiker> <...Reden>',
			group: 'mod',
			guildOnly: true
		});
	}

	@modOnly
	@using(resolve('user: User, ...reason: String'))
	@using(expect('user: User, ...reason: String'))
	public async action(message: Message, [user, reason]: [User, string]): Promise<any>
	{
		if (this.client.mod.actions.isLocked(message.guild, user))
			return message.channel.send('That user is currently being moderated by someone else');

		this.client.mod.actions.setLock(message.guild, user);
		try
		{
			if (user.id === message.author.id)
				return message.channel.send(`Ik denk niet dat je jezelf wilt bannen`);

			let member: GuildMember;
			try { member = await message.guild.fetchMember(user); }
			catch {}

			const modRole: string = await message.guild.storage.settings.get('modrole');
			if ((member && member.roles.has(modRole)) || user.id === message.guild.ownerID || user.bot)
				return message.channel.send('Je kan deze gebruiker niet bannen omdat hij de modpermissies heeft');

			const bans: Collection<string, User> = await message.guild.fetchBans();
			if (bans.has(user.id)) return message.channel.send('Deze gebruiker is al verbannen');

			const offenses: any = await this.client.mod.actions.checkUserHistory(message.guild, user);
			const embed: RichEmbed = new RichEmbed()
				.setColor(offenses.color)
				.setDescription(`**Reden:** ${reason}`)
				.setAuthor(user.tag, user.avatarURL)
				.setFooter(offenses.toString());

			const [result]: [PromptResult] = <[PromptResult]> await prompt(message,
				'Are you sure you want to issue this ban? (__j__a | __n__ee)',
				/^(?:ja|j)$/i, /^(?:nee|n)$/i, { embed });
			if (result === PromptResult.TIMEOUT) return message.channel.send('Commando taak genannuleerd wegens inactiviteit');
			if (result === PromptResult.FAILURE) return message.channel.send('Okee, ban geannuleerd.');

			try { await user.send(res('MSG_DM_BAN', { guildName: message.guild.name, reason }), { split: true }); }
			catch { this._logger.error(`Failed to send ban DM to ${user.tag}`); }

			const banning: Message = <Message> await message.channel.send(`Aan het bannen: ${user.tag}...`);
			this.client.mod.logs.setCachedCase(message.guild, user, 'Ban');

			try { await this.client.mod.actions.ban(user, message.guild, reason); }
			catch (err)
			{
				this.client.mod.logs.removeCachedCase(message.guild, user, 'Ban');
				return banning.edit(`Error while banning: ${err}`);
			}

			await this.client.mod.logs.logCase(user, message.guild, 'Ban', reason, message.author);
			this._logger.log(`Banned: '${user.tag}' from '${message.guild.name}'`);
			return banning.edit(`De gebruiker ${user.tag} is succesvol verbannen`);
		}
		finally { this.client.mod.actions.removeLock(message.guild, user); }
	}
}
