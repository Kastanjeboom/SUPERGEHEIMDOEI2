import { Command, Message, Middleware, CommandDecorators } from 'yamdbf';
import { User, GuildMember, Guild } from 'discord.js';
import { ModClient } from '../../../client/ModClient';
import { modOnly } from '../../../util/Util';

const { resolve, expect } = Middleware;
const { using } = CommandDecorators;

export default class extends Command<ModClient>
{
	public constructor()
	{
		super({
			name: 'unmute',
			desc: 'Unmute a user',
			usage: '<prefix>unmute <Gebruiker>',
			group: 'mod',
			guildOnly: true
		});
	}

	@modOnly
	@using(resolve('member: Member'))
	@using(expect('member: Member'))
	public async action(message: Message, [member]: [GuildMember]): Promise<any>
	{
		if (!await this.client.mod.hasSetMutedRole(message.guild)) return message.channel.send(
			`Deze server heeft geen mute rol`);

		const mutedRole: string = await message.guild.storage.settings.get('mutedrole');
		if (!member.roles.has(mutedRole)) return message.channel.send(`Deze gebruiker is niet gemuted`);

		const user: User = member.user;
		const unmuting: Message = <Message> await message.channel.send(`Aan het unmuten: ${user.tag}...`);

		try
		{
			await this.client.mod.actions.unmute(member, message.guild);
			await this.client.mod.managers.mute.remove(member.guild, member.id);
			user.send(`Je bent geunmuted van de ${message.guild.name} discord. Je kan nu weer berichten verzenden.`);
			return unmuting.edit(`Succesvol unmuted: ${user.tag}`);
		}
		catch (err)
		{
			return message.channel.send(`Foutrapport: \n${err}`);
		}
	}
}
