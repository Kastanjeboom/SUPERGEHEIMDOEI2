import { Command, Message, Middleware, CommandDecorators, Logger, logger, Lang, ResourceLoader } from 'yamdbf';
import { User, GuildMember, Collection } from 'discord.js';
import { ModClient } from '../../../client/ModClient';
import { modOnly } from '../../../util/Util';

const { resolve, expect } = Middleware;
const { using } = CommandDecorators;
const res: ResourceLoader = Lang.createResourceLoader('en_us');

export default class extends Command<ModClient>
{
	@logger('Command:Softban')
	private readonly _logger: Logger;

	public constructor()
	{
		super({
			name: 'softban',
			desc: 'Softban a user',
			usage: '<prefix>softban <Gebruiker> <...Reden>',
			group: 'mod',
			guildOnly: true
		});
	}

	@modOnly
	@using(resolve('user: User, ...reason: String'))
	@using(expect('user: User, ...reason: String'))
	public async action(message: Message, [user, reason]: [User, string]): Promise<any>
	{
		if (this.client.mod.actions.isLocked(message.guild, user))
			return message.channel.send('That user is currently being moderated by someone else');

		this.client.mod.actions.setLock(message.guild, user);
		try
		{
			if (user.id === message.author.id)
				return message.channel.send(`Ik denk niet dat je jezelf wilt bannen`);

			let member: GuildMember;
			try { member = await message.guild.fetchMember(user); }
			catch (err) {}

			const modRole: string = await message.guild.storage.settings.get('modrole');
			if ((member && member.roles.has(modRole)) || user.id === message.guild.ownerID || user.bot)
				return message.channel.send('Je kan deze gebruiker niet softbannen omdat hij de modpermissies heeft.');

			const bans: Collection<string, User> = await message.guild.fetchBans();
			if (bans.has(user.id)) return message.channel.send('Deze gebruiker is al verbannen');

			const kicking: Message = <Message> await message.channel
				.send(`Softbanning ${user.tag}... *(Unbannen.....)*`);

			try { await user.send(res('MSG_DM_SOFTBAN', { guildName: message.guild.name, reason: reason })); }
			catch { this._logger.error(`Kon geen privebericht sturen naar ${user.tag}`); }

			this.client.mod.logs.setCachedCase(message.guild, user, 'Ban');
			this.client.mod.logs.setCachedCase(message.guild, user, 'Unban');
			try { await this.client.mod.actions.softban(user, message.guild, reason); }
			catch (err)
			{
				this.client.mod.logs.removeCachedCase(message.guild, user, 'Ban');
				this.client.mod.logs.removeCachedCase(message.guild, user, 'Unban');
				return kicking.edit(`Foutrapport: ${err}`);
			}

			await this.client.mod.logs.logCase(user, message.guild, 'Softban', reason, message.author);
			this._logger.log(`Gebruiker gekicked: '${user.tag}' van'${message.guild.name}'`);
			return kicking.edit(`Successfully softbanned ${user.tag}`);
		}
		finally { this.client.mod.actions.removeLock(message.guild, user); }
	}
}
