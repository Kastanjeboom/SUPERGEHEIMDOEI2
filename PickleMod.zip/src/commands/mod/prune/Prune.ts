import { Command, Message, Middleware, CommandDecorators } from 'yamdbf';
import { GuildMember } from 'discord.js';
import { ModClient } from '../../../client/ModClient';
import { modOnly } from '../../../util/Util';

const { resolve, expect } = Middleware;
const { using } = CommandDecorators;

export default class extends Command<ModClient>
{
	public constructor()
	{
		super({
			name: 'deletmsg',
			desc: 'Remove the last given quantity of messages for the provided member',
			usage: '<prefix>deletemsg <Radius> <Lid>',
			info: 'Removes as many messages as possible from the given member within the given quantity of messages. Can delete up to 100 messages per command call',
			group: 'prune',
			guildOnly: true
		});
	}

	@modOnly
	@using(resolve('quantity: Number, member: Member'))
	@using(expect('quantity: Number, member: Member'))
	public async action(message: Message, [quantity, member]: [int, GuildMember]): Promise<any>
	{
		if (!quantity || quantity < 1)
			return message.channel.send('Geen geldig nummer');

		if (!member) return message.channel.send('You must mention a user to prune');

		const messages: Message[] = (await message.channel.fetchMessages(
			{ limit: 100, before: message.id }))
			.filter((a: Message) => a.author.id === member.id)
			.array();
		messages.length = Math.min(quantity, messages.length);
		if (messages.length === 0) return message.reply(
			Er zijn geen berichten verwijderd');

		if (messages.length === 1) await messages[0].delete();
		else await message.channel.bulkDelete(messages);
		if (member.id === message.author.id) message.delete();

		return message.author.send('Operatie voltooid');
	}
}
