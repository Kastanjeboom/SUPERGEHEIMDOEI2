/**
 * Storage entry containing all active appeals
 */
type ActiveAppeals = { [id: string]: string };
